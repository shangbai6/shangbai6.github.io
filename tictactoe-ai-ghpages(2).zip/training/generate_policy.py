"""重新生成 model.json（AI 作为 O 时的最优走子查表）

用法：
    python3 training/generate_policy.py

会在仓库根目录写入/覆盖：model.json

说明：
- 井字棋是可完全求解的零和博弈，因此该“训练/生成”得到的是最优策略（不败）。
- 这里只为“轮到 O 走”的合法局面生成最优步（把棋盘编码成 9 字符串，空位用 '-'）。
"""

from __future__ import annotations
from functools import lru_cache
from pathlib import Path
import json

WIN_LINES = [
    (0,1,2),(3,4,5),(6,7,8),
    (0,3,6),(1,4,7),(2,5,8),
    (0,4,8),(2,4,6),
]

def winner(board: tuple[str|None, ...]) -> str|None:
    for a,b,c in WIN_LINES:
        if board[a] and board[a] == board[b] == board[c]:
            return board[a]
    return None

def is_terminal(board: tuple[str|None, ...]) -> bool:
    return winner(board) is not None or all(x is not None for x in board)

def turn_from_counts(board: tuple[str|None, ...]) -> str|None:
    x = sum(1 for c in board if c == "X")
    o = sum(1 for c in board if c == "O")
    if x == o: return "X"
    if x == o + 1: return "O"
    return None

def is_legal(board: tuple[str|None, ...]) -> bool:
    x = sum(1 for c in board if c == "X")
    o = sum(1 for c in board if c == "O")
    if not (x == o or x == o + 1):
        return False
    w = winner(board)
    if w == "X" and x != o + 1: return False
    if w == "O" and x != o: return False
    # 双方同时赢属于非法
    wx = wo = False
    for a,b,c in WIN_LINES:
        if board[a] and board[a] == board[b] == board[c]:
            wx |= (board[a] == "X")
            wo |= (board[a] == "O")
    return not (wx and wo)

@lru_cache(maxsize=None)
def minimax_value(board: tuple[str|None, ...], turn: str, depth: int = 0) -> int:
    w = winner(board)
    if w == "O": return 10 - depth
    if w == "X": return depth - 10
    if all(x is not None for x in board): return 0

    moves = [i for i,c in enumerate(board) if c is None]
    if turn == "O":
        best = -999
        for i in moves:
            b = list(board); b[i] = "O"
            best = max(best, minimax_value(tuple(b), "X", depth + 1))
        return best
    else:
        best = 999
        for i in moves:
            b = list(board); b[i] = "X"
            best = min(best, minimax_value(tuple(b), "O", depth + 1))
        return best

def best_move_O(board: tuple[str|None, ...]) -> int:
    pref = [4,0,2,6,8,1,3,5,7]
    moves = [i for i,c in enumerate(board) if c is None]
    best_val = -999
    best_moves: list[int] = []
    for i in moves:
        b = list(board); b[i] = "O"
        val = minimax_value(tuple(b), "X", 1)
        if val > best_val:
            best_val = val
            best_moves = [i]
        elif val == best_val:
            best_moves.append(i)
    for p in pref:
        if p in best_moves:
            return p
    return best_moves[0]

def generate_policy() -> dict[str, int]:
    policy: dict[str, int] = {}
    visited: set[tuple[str|None, ...]] = set()

    def rec(board: tuple[str|None, ...]) -> None:
        if board in visited:
            return
        visited.add(board)

        if not is_legal(board) or is_terminal(board):
            return

        t = turn_from_counts(board)
        if t == "O":
            key = "".join(c if c is not None else "-" for c in board)
            policy[key] = best_move_O(board)

        for i,c in enumerate(board):
            if c is None:
                b = list(board); b[i] = t
                rec(tuple(b))

    rec(tuple([None] * 9))
    return policy

def main():
    policy = generate_policy()
    out = Path(__file__).resolve().parents[1] / "model.json"
    out.write_text(json.dumps(policy, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {len(policy)} states to {out}")

if __name__ == "__main__":
    main()
