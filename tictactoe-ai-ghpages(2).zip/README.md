# 井字棋 AI（GitHub Pages 一键部署）

这是一个**纯静态**井字棋网页：你与 AI 对战。默认你执 **X**，AI 执 **O**。  
AI 优先使用仓库里的 `model.json`（离线生成的最优策略查表），加载失败会自动回退到 Minimax（同样不败）。

## 一键部署到 GitHub Pages（推荐：GitHub Actions）

1. 把本项目上传到你的 GitHub 仓库（或用“Upload files”直接把文件拖上去）。
2. 进入仓库：**Settings → Pages**
3. 在 **Build and deployment** 的 **Source** 选择：**GitHub Actions**
4. 推送一次代码（或点一下 Actions 里的 rerun），等工作流 `Deploy to GitHub Pages` 跑完。
5. Pages 会给你一个网址（类似 `https://<用户名>.github.io/<仓库名>/`）。

> 工作流文件在：`.github/workflows/pages.yml`

## 本地运行

直接双击打开 `index.html` 即可（或用任意静态服务器）。

## 可选：重新“训练/生成”策略（Python）

`training/generate_policy.py` 会重新生成 `model.json`（策略查表）。  
井字棋是可完全求解游戏，所以这里生成的是“最优策略”（不败）。

```bash
python3 training/generate_policy.py
# 生成/覆盖根目录的 model.json
```

## 文件结构

- `index.html`：页面
- `style.css`：样式
- `app.js`：交互 + AI（查表/Minimax）
- `model.json`：离线策略（AI=O 且轮到 O 时用）
- `training/generate_policy.py`：生成策略文件
- `.github/workflows/pages.yml`：GitHub Pages 自动部署
