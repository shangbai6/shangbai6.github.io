// 井字棋 AI：默认你是 X，AI 是 O。
// 优先使用离线生成的 model.json（策略查表），失败则回退到 Minimax（同样不败）。

const boardEl = document.getElementById("board");
const statusEl = document.getElementById("status");
const newGameBtn = document.getElementById("newGameBtn");
const aiStartsChk = document.getElementById("aiStartsChk");
const mediumChk = document.getElementById("mediumChk");

const WIN_LINES = [
  [0,1,2],[3,4,5],[6,7,8],
  [0,3,6],[1,4,7],[2,5,8],
  [0,4,8],[2,4,6],
];

let cells = [];
let board = Array(9).fill(null);
let gameOver = false;

let human = "X";
let ai = "O";
let turn = "X";

let policy = null; // { "X--O-X---": 4, ... } 仅在 AI=O 且轮到 O 时使用

function boardKey(b) {
  return b.map(v => v ?? "-").join("");
}

function getWinner(b) {
  for (const [a,c,d] of WIN_LINES) {
    if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a];
  }
  return null;
}

function getWinLine(b) {
  for (const line of WIN_LINES) {
    const [a,c,d] = line;
    if (b[a] && b[a] === b[c] && b[a] === b[d]) return line;
  }
  return null;
}

function isDraw(b) {
  return !getWinner(b) && b.every(x => x !== null);
}

function setStatus(msg) {
  statusEl.textContent = msg;
}

function render() {
  for (let i = 0; i < 9; i++) {
    const v = board[i];
    cells[i].textContent = v ?? "";
    cells[i].disabled = gameOver || v !== null || turn !== human;
    cells[i].classList.toggle("win", false);
  }
  const winLine = getWinLine(board);
  if (winLine) {
    for (const idx of winLine) cells[idx].classList.add("win");
  }
}

function resetGame() {
  board = Array(9).fill(null);
  gameOver = false;

  if (aiStartsChk.checked) {
    // AI 先手：AI= X，人类= O（此模式走 Minimax）
    ai = "X";
    human = "O";
    turn = "X";
    setStatus("AI 先手（AI= X）");
    render();
    setTimeout(aiMove, 120);
  } else {
    // 默认：人类 X 先手，AI= O（优先查表策略）
    human = "X";
    ai = "O";
    turn = "X";
    setStatus(policy ? "你的回合（X）· AI 策略已加载" : "你的回合（X）· AI 使用 Minimax");
    render();
  }
}

function endGame(msg) {
  gameOver = true;
  setStatus(msg);
  render();
}

function applyMove(i, player) {
  if (board[i] !== null || gameOver) return false;
  board[i] = player;
  return true;
}

function onCellClick(i) {
  if (gameOver) return;

  if (turn !== human) return;
  if (!applyMove(i, human)) return;

  const w = getWinner(board);
  if (w) return endGame(w === human ? "你赢了！" : "AI 赢了。");
  if (isDraw(board)) return endGame("平局。");

  turn = ai;
  render();
  setTimeout(aiMove, 120);
}

/** ---------- AI（查表优先，Minimax 兜底） ---------- **/
function aiMove() {
  if (gameOver) return;
  if (turn !== ai) return;

  // 中等难度：少量概率随机走一步
  const medium = mediumChk.checked;
  const empty = board.map((v,i) => v === null ? i : null).filter(v => v !== null);
  if (medium && empty.length > 0 && Math.random() < 0.18) {
    const r = empty[Math.floor(Math.random() * empty.length)];
    applyMove(r, ai);
  } else {
    const move = pickBestMove(board, ai);
    applyMove(move, ai);
  }

  const w = getWinner(board);
  if (w) return endGame(w === human ? "你赢了！" : "AI 赢了。");
  if (isDraw(board)) return endGame("平局。");

  turn = human;
  setStatus(policy && ai === "O" ? "你的回合（X）· AI（查表）" : "你的回合");
  render();
}

function pickBestMove(b, aiSymbol) {
  // 仅当 AI=O 且轮到 O 时，尝试查表
  if (policy && aiSymbol === "O") {
    const key = boardKey(b);
    const mv = policy[key];
    if (Number.isInteger(mv) && b[mv] === null) return mv;
  }
  // 兜底：Minimax（不败）
  return minimaxBestMove(b, aiSymbol);
}

function minimaxBestMove(b, aiSymbol) {
  const opponent = aiSymbol === "X" ? "O" : "X";
  const moves = [];
  for (let i = 0; i < 9; i++) if (b[i] === null) moves.push(i);

  // 偏好：中心 > 角 > 边（让走法更“漂亮”）
  const pref = [4,0,2,6,8,1,3,5,7];

  let bestVal = -Infinity;
  let bestMoves = [];

  for (const m of moves) {
    const nb = b.slice();
    nb[m] = aiSymbol;
    const val = minimaxValue(nb, opponent, aiSymbol, 1);
    if (val > bestVal) {
      bestVal = val;
      bestMoves = [m];
    } else if (val === bestVal) {
      bestMoves.push(m);
    }
  }

  for (const p of pref) if (bestMoves.includes(p)) return p;
  return bestMoves[0] ?? moves[0] ?? 0;
}

const mmCache = new Map();
// 评分：AI 赢越快越好；输则尽量拖延；平局=0
function minimaxValue(b, turnSymbol, aiSymbol, depth) {
  const key = b.join("") + "|" + turnSymbol + "|" + aiSymbol;
  if (mmCache.has(key)) return mmCache.get(key);

  const w = getWinner(b);
  if (w) {
    const score = (w === aiSymbol) ? (10 - depth) : (depth - 10);
    mmCache.set(key, score);
    return score;
  }
  if (b.every(x => x !== null)) {
    mmCache.set(key, 0);
    return 0;
  }

  const opponent = turnSymbol === "X" ? "O" : "X";
  const moves = [];
  for (let i = 0; i < 9; i++) if (b[i] === null) moves.push(i);

  let best = (turnSymbol === aiSymbol) ? -Infinity : Infinity;
  for (const m of moves) {
    const nb = b.slice();
    nb[m] = turnSymbol;
    const val = minimaxValue(nb, opponent, aiSymbol, depth + 1);
    if (turnSymbol === aiSymbol) best = Math.max(best, val);
    else best = Math.min(best, val);
  }

  mmCache.set(key, best);
  return best;
}

/** ---------- 初始化 ---------- **/
function buildBoardUI() {
  boardEl.innerHTML = "";
  cells = [];
  for (let i = 0; i < 9; i++) {
    const btn = document.createElement("button");
    btn.className = "cell";
    btn.type = "button";
    btn.setAttribute("aria-label", `格子 ${i+1}`);
    btn.addEventListener("click", () => onCellClick(i));
    boardEl.appendChild(btn);
    cells.push(btn);
  }
}

async function loadPolicy() {
  try {
    const res = await fetch("./model.json", { cache: "no-store" });
    if (!res.ok) throw new Error("HTTP " + res.status);
    policy = await res.json();
  } catch {
    policy = null;
  }
}

newGameBtn.addEventListener("click", resetGame);
aiStartsChk.addEventListener("change", resetGame);

buildBoardUI();
await loadPolicy();
resetGame();
